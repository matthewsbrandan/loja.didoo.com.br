<div class="header y py-1 py-lg-8">
    <div class="container">
        <div class="header-body text-center mb-1">
            <div class="row justify-content-center">
                <a class="navbar-brand d-none" href="/">
                    
                    <img src="{{ config('global.site_logo') }}" width="300" height="300" class="" alt="..."> 
                </a>
            </div>
        </div>
    </div>
    
</div>